import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Main extends JPanel implements ActionListener, KeyListener {
    private ArrayList<Vivora> vivoras;
    private Vivora vivoraActiva;
    private JButton btnAgregarVivora;
    private JList<String> listaVivoras;
    private DefaultListModel<String> modeloLista;
    private Random random;
    private Point comida;
    private static final int ANCHO = 1200;
    private static final int ALTO = 1000;
    private static final int TAMANO_CELDA = 100;
    private static final int ANCHO_PANEL_DERECHO = 200;

    public Main() {
        setPreferredSize(new Dimension(ANCHO + ANCHO_PANEL_DERECHO, ALTO));
        setBackground(Color.BLACK);
        vivoras = new ArrayList<>();
        random = new Random();

        btnAgregarVivora = new JButton("Agregar Víbora");
        btnAgregarVivora.addActionListener(this);

        modeloLista = new DefaultListModel<>();
        listaVivoras = new JList<>(modeloLista);
        listaVivoras.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int index = listaVivoras.getSelectedIndex();
                if (index != -1) {
                    setVivoraActiva(vivoras.get(index));
                }
            }
        });

        JPanel panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setPreferredSize(new Dimension(ANCHO_PANEL_DERECHO, ALTO));
        panelDerecho.add(btnAgregarVivora, BorderLayout.NORTH);
        panelDerecho.add(new JScrollPane(listaVivoras), BorderLayout.CENTER);

        setLayout(new BorderLayout());
        add(panelDerecho, BorderLayout.EAST);

        addKeyListener(this);
        setFocusable(true);
        requestFocusInWindow();

        generarComida();

        Timer timer = new Timer(100, e -> repaint());
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(Color.DARK_GRAY);
        for (int x = 0; x < ANCHO; x += TAMANO_CELDA) {
            g.drawLine(x, 0, x, ALTO);
        }
        for (int y = 0; y < ALTO; y += TAMANO_CELDA) {
            g.drawLine(0, y, ANCHO, y);
        }

        for (Vivora vivora : vivoras) {
            vivora.dibujar(g);
        }

        dibujarComida(g);
        detectarColisiones();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAgregarVivora) {
            agregarVivora();
        }
    }

    private void agregarVivora() {
        Point nuevaPosicion = generarPosicionValida();
        if (nuevaPosicion == null) {
            JOptionPane.showMessageDialog(this, "No hay espacio disponible para una nueva víbora.");
            return;
        }

        Vivora nuevaVivora = new Vivora(nuevaPosicion.x, nuevaPosicion.y);
        vivoras.add(nuevaVivora);
        modeloLista.addElement("Víbora " + vivoras.size());

        if (vivoraActiva != null) {
            vivoraActiva.setControladaPorUsuario(false);
            iniciarMovimientoAleatorio(vivoraActiva);
        }

        setVivoraActiva(nuevaVivora);
        new Thread(nuevaVivora).start();

        requestFocusInWindow();
    }

    private void setVivoraActiva(Vivora vivora) {
        vivoraActiva = vivora;
        vivoraActiva.setControladaPorUsuario(true);
    }

    private Point generarPosicionValida() {
        for (int intentos = 0; intentos < 100; intentos++) {
            int x = random.nextInt(ANCHO / TAMANO_CELDA) * TAMANO_CELDA;
            int y = random.nextInt(ALTO / TAMANO_CELDA) * TAMANO_CELDA;
            Point nuevaPosicion = new Point(x, y);

            boolean posicionValida = true;
            for (Vivora vivora : vivoras) {
                if (vivora.getCabeza().getX() == nuevaPosicion.x && vivora.getCabeza().getY() == nuevaPosicion.y) {
                    posicionValida = false;
                    break;
                }
            }

            if (posicionValida) {
                return nuevaPosicion;
            }
        }
        return null;
    }

    private void iniciarMovimientoAleatorio(Vivora vivora) {
        new Thread(() -> {
            String[] direcciones = {"arriba", "abajo", "izquierda", "derecha"};
            Random random = new Random();
            while (vivora.estaViva() && !vivora.isControladaPorUsuario()) {
                int direccionAleatoria = random.nextInt(4);
                vivora.setDireccion(direcciones[direccionAleatoria]);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (vivoraActiva != null && vivoraActiva.isControladaPorUsuario()) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:    vivoraActiva.setDireccion("arriba");     break;
                case KeyEvent.VK_DOWN:  vivoraActiva.setDireccion("abajo");      break;
                case KeyEvent.VK_LEFT:  vivoraActiva.setDireccion("izquierda");  break;
                case KeyEvent.VK_RIGHT: vivoraActiva.setDireccion("derecha");    break;
            }
        }
    }

    private void detectarColisiones() {
        for (Vivora vivora : vivoras) {
            if (vivora.estaViva()) {
                // Colisión con la comida
                if (vivora.getCabeza().getX() == comida.x && vivora.getCabeza().getY() == comida.y) {
                    vivora.comer();
                    generarComida();
                }

                // Colisión con los bordes
                if (vivora.getCabeza().getX() < 0 || vivora.getCabeza().getX() >= ANCHO ||
                        vivora.getCabeza().getY() < 0 || vivora.getCabeza().getY() >= ALTO) {
                    vivora.setEstaViva(false);
                }

                // Colisión con otras víboras o consigo misma
                for (Vivora otraVivora : vivoras) {
                    Nodo nodo = otraVivora.getCabeza().getSiguienteNodo(); // Empezamos desde el segundo nodo
                    while (nodo != null) {
                        if (vivora.getCabeza().getX() == nodo.getX() &&
                                vivora.getCabeza().getY() == nodo.getY()) {
                            vivora.setEstaViva(false);
                            break;
                        }
                        nodo = nodo.getSiguienteNodo();
                    }
                    if (!vivora.estaViva()) break;
                }
            }
        }

        // Remover víboras muertas
        vivoras.removeIf(vivora -> !vivora.estaViva());
        actualizarListaVivoras();
    }

    private void generarComida() {
        int x = (random.nextInt(ANCHO / TAMANO_CELDA) * TAMANO_CELDA);
        int y = (random.nextInt(ALTO / TAMANO_CELDA) * TAMANO_CELDA);
        comida = new Point(x, y);
    }

    private void dibujarComida(Graphics g) {
        g.setColor(Color.RED);
        g.fillOval(comida.x, comida.y, TAMANO_CELDA, TAMANO_CELDA);
    }

    private void actualizarListaVivoras() {
        modeloLista.clear();
        for (int i = 0; i < vivoras.size(); i++) {
            modeloLista.addElement("Víbora " + (i + 1));
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Juego de Víbora");
        Main panel = new Main();
        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}



