import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Vivora implements Runnable {
    private Nodo cabeza;
    private String direccion;
    private boolean controladaPorUsuario;
    private boolean estaViva;
    private Random random;
    private int velocidad;
    private Color color;
    private boolean haComido;

    public Vivora(int x, int y, Color color) {
        cabeza = new Nodo(x, y);
        direccion = "derecha";
        controladaPorUsuario = false;
        estaViva = true;
        random = new Random();
        velocidad = 500;
        this.color = color;
        this.haComido = false;
    }

    public Vivora(int x, int y) {
        this(x, y, generarColorAleatorio());
    }

    @Override
    public void run() {
        while (estaViva) {
            if (!controladaPorUsuario) {
                cambiarDireccionAutomatica();
            }
            mover();
            try {
                Thread.sleep(velocidad);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void mover() {
        int newX = cabeza.getX();
        int newY = cabeza.getY();

        switch (getDireccion()) {
            case "arriba":    newY -= 100; break;
            case "abajo":     newY += 100; break;
            case "izquierda": newX -= 100; break;
            case "derecha":   newX += 100; break;
        }

        Nodo nuevoNodo = new Nodo(newX, newY);
        nuevoNodo.setSiguienteNodo(cabeza);
        cabeza = nuevoNodo;

        if (!haComido) {
            // Si no ha comido, eliminar el último nodo
            Nodo actual = cabeza;
            while (actual.getSiguienteNodo() != null && actual.getSiguienteNodo().getSiguienteNodo() != null) {
                actual = actual.getSiguienteNodo();
            }
            if (actual.getSiguienteNodo() != null) {
                actual.setSiguienteNodo(null);
            }
        } else {
            // Si ha comido, no se elimina el último nodo ni resetear haComido
            haComido = false;
        }
    }

    public void cambiarDireccionAutomatica() {
        String[] direcciones = {"arriba", "abajo", "izquierda", "derecha"};
        String nuevaDireccion;
        do {
            nuevaDireccion = direcciones[random.nextInt(4)];
        } while (esDireccionOpuesta(nuevaDireccion));
        setDireccion(nuevaDireccion);
    }

    public void comer() {
        haComido = true;
        velocidad = Math.max(100, velocidad - 20);
    }

    public Nodo getCola() {
        return getColaRecursivo(cabeza);
    }

    private Nodo getColaRecursivo(Nodo nodo) {
        if (nodo.getSiguienteNodo() == null) {
            return nodo;
        }
        return getColaRecursivo(nodo.getSiguienteNodo());
    }

    public void dibujar(Graphics g) {
        Nodo nodo = cabeza;
        g.setColor(color);
        while (nodo != null) {
            g.fillOval(nodo.getX(), nodo.getY(), 100, 100);
            nodo = nodo.getSiguienteNodo();
        }
    }

    // Getters y setters

    public boolean estaViva() {
        return estaViva;
    }

    public void setEstaViva(boolean estaViva) {
        this.estaViva = estaViva;
    }

    public Nodo getCabeza() {
        return cabeza;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        if (!esDireccionOpuesta(direccion)) {
            this.direccion = direccion;
        }
    }

    public boolean isControladaPorUsuario() {
        return controladaPorUsuario;
    }

    public void setControladaPorUsuario(boolean controladaPorUsuario) {
        this.controladaPorUsuario = controladaPorUsuario;
    }

    private boolean esDireccionOpuesta(String nuevaDireccion) {
        return (direccion.equals("arriba") && nuevaDireccion.equals("abajo")) ||
                (direccion.equals("abajo") && nuevaDireccion.equals("arriba")) ||
                (direccion.equals("izquierda") && nuevaDireccion.equals("derecha")) ||
                (direccion.equals("derecha") && nuevaDireccion.equals("izquierda"));
    }

    private static Color generarColorAleatorio() {
        Random random = new Random();
        return new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}



