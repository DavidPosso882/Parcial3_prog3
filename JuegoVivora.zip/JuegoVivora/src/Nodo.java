public class Nodo {
    private int x, y;
    private Nodo siguienteNodo;

    public Nodo(int x, int y) {
        this.x = x;
        this.y = y;
        this.siguienteNodo = null;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Nodo getSiguienteNodo() {
        return siguienteNodo;
    }

    public void setSiguienteNodo(Nodo siguienteNodo) {
        this.siguienteNodo = siguienteNodo;
    }

    public void mover(int newX, int newY) {
        if (siguienteNodo != null) {
            siguienteNodo.mover(x, y);
        }
        x = newX;
        y = newY;
    }
}

